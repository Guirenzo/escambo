const express = require('express');
const app = express();
const cors = require('cors'); // importe o cors
const usuarioRoutes = require('./routes/usuarioRoutes');
const servicoRoutes = require('./routes/servicoRoutes');
const freelancerRoutes = require('./routes/freelancerRoutes');
const anuncioRoutes = require('./routes/anuncioRoutes');
const avaliacaoRoutes = require('./routes/avaliacaoRoutes'); 
const pagamentoRoutes = require('./routes/pagamentoRoutes');

// Middleware para parsing de JSON
app.use(express.json());

app.use(cors());

// Usando as rotas
app.use('/usuarios', usuarioRoutes);
app.use('/servicos', servicoRoutes);
app.use('/freelancers', freelancerRoutes);
app.use('/anuncios', anuncioRoutes);
app.use('/avaliacoes', avaliacaoRoutes);
app.use('/pagamentos', pagamentoRoutes);


app.listen(3000, () => {
  console.log('Servidor rodando na porta 3000');
});
