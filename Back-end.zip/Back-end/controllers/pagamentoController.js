const Pagamento = require('../models/pagamentoModel');  // Certifique-se de que o caminho para o modelo está correto

const pagamentoController = {
  // Função para obter todos os pagamentos
  getAllPagamentos: (req, res) => {
    Pagamento.findAll()  // Supondo que você esteja usando Sequelize ou similar
      .then(pagamentos => res.json(pagamentos))
      .catch(error => res.status(500).json({ error: 'Erro ao buscar pagamentos' }));
  },

  // Função para obter um pagamento pelo ID
  getPagamentoById: (req, res) => {
    const { id } = req.params;
    Pagamento.findByPk(id)
      .then(pagamento => {
        if (pagamento) {
          res.json(pagamento);
        } else {
          res.status(404).json({ error: 'Pagamento não encontrado' });
        }
      })
      .catch(error => res.status(500).json({ error: 'Erro ao buscar pagamento' }));
  },

  // Função para criar um pagamento
  createPagamento: (req, res) => {
    const { cliente_id, servico_id, valor_total, valor_freelancer, valor_comissao, metodo_pagamento } = req.body;
    Pagamento.create({ cliente_id, servico_id, valor_total, valor_freelancer, valor_comissao, metodo_pagamento })
      .then(pagamento => res.status(201).json(pagamento))
      .catch(error => res.status(500).json({ error: 'Erro ao criar pagamento' }));
  }
};

module.exports = pagamentoController;
