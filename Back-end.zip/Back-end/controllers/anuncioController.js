// controllers/anuncioController.js
const Anuncio = require('../models/anuncioModel');

exports.getAllAnuncios = async (req, res) => {
  try {
    const anuncios = await Anuncio.findAll();
    res.json(anuncios);
  } catch (err) {
    console.error('Erro ao buscar anúncios:', err);
    res.status(500).json({ error: 'Erro ao buscar anúncios' });
  }
};

exports.getAnuncioById = async (req, res) => {
  const { id } = req.params;
  try {
    const anuncio = await Anuncio.findByPk(id);
    if (!anuncio) {
      return res.status(404).json({ message: 'Anúncio não encontrado' });
    }
    res.json(anuncio);
  } catch (err) {
    console.error(`Erro ao buscar anúncio com ID ${id}:`, err);
    res.status(500).json({ error: 'Erro ao buscar anúncio' });
  }
};

exports.createAnuncio = async (req, res) => {
  try {
    const novoAnuncio = await Anuncio.create(req.body);
    res.status(201).json(novoAnuncio);
  } catch (err) {
    console.error('Erro ao criar anúncio:', err);
    res.status(500).json({ error: 'Erro ao criar anúncio' });
  }
};
