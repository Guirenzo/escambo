const Freelancer = require('../models/freelancerModel');

exports.getAllFreelancers = async (req, res) => {
  try {
    const freelancers = await Freelancer.findAll();
    res.json(freelancers);
  } catch (err) {
    console.error('Erro ao buscar freelancers:', err);
    res.status(500).json({ error: 'Erro ao buscar freelancers' });
  }
};

exports.getFreelancerById = async (req, res) => {
  const { id } = req.params;
  try {
    const freelancer = await Freelancer.findByPk(id);
    if (!freelancer) {
      return res.status(404).json({ message: 'Freelancer não encontrado' });
    }
    res.json(freelancer);
  } catch (err) {
    console.error(`Erro ao buscar freelancer com ID ${id}:`, err);
    res.status(500).json({ error: 'Erro ao buscar freelancer' });
  }
};

exports.createFreelancer = async (req, res) => {
  try {
    const novoFreelancer = await Freelancer.create(req.body);
    res.status(201).json(novoFreelancer);
  } catch (err) {
    console.error('Erro ao criar freelancer:', err);
    res.status(500).json({ error: 'Erro ao criar freelancer' });
  }
};
