const Freelancer = require('../models/freelancerModel');
const Usuario = require('../models/usuarioModel');

exports.getAllFreelancers = async (req, res) => {
  try {
    const freelancers = await Freelancer.findAll({
      include: {
        model: Usuario,
        as: 'usuario',          // tem que ser o mesmo 'as' que no model
        attributes: ['nome', 'email']
      }
    });

    res.json(freelancers);
  } catch (err) {
    console.error('Erro ao buscar freelancers:', err);
    res.status(500).json({ error: 'Erro ao buscar freelancers' });
  }
};


exports.getFreelancerById = async (req, res) => {
  const { id } = req.params;
  try {
    const freelancer = await Freelancer.findByPk(id, {
      include: {
        model: Usuario,
        as: 'usuario',
        attributes: ['nome', 'email']
      }
    });
    if (!freelancer) {
      return res.status(404).json({ message: 'Freelancer não encontrado' });
    }
    res.json(freelancer);
  } catch (err) {
    console.error(`Erro ao buscar freelancer com ID ${id}:`, err);
    res.status(500).json({ error: 'Erro ao buscar freelancer' });
  }
};

exports.createFreelancer = async (req, res) => {
  try {
    const { nome, email, senha, descricao, area_atuacao, preco, portfolio } = req.body;

    // Criar usuário sem criptografia de senha
    const usuario = await Usuario.create({
      nome,
      email,
      senha,  // senha em texto simples
      tipo: 'freelancer',
    });

    const freelancer = await Freelancer.create({
      usuario_id: usuario.id,
      descricao,
      area_atuacao,
      preco,
      portfolio,
      destaque: false,
      avaliacao_media: 0,
    });

    res.status(201).json({ usuario, freelancer });
  } catch (err) {
    console.error('Erro ao criar freelancer:', err);
    res.status(500).json({ error: 'Erro ao criar freelancer' });
  }
};

