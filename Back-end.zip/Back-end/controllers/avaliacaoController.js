// controllers/avaliacaoController.js
const Avaliacao = require('../models/avaliacaoModel');

const getAllAvaliacoes = async (req, res) => {
  try {
    const avaliacoes = await Avaliacao.findAll();
    res.status(200).json(avaliacoes);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao obter avaliações', error });
  }
};

const getAvaliacaoById = async (req, res) => {
  const { id } = req.params;
  try {
    const avaliacao = await Avaliacao.findByPk(id);
    if (!avaliacao) {
      return res.status(404).json({ message: 'Avaliação não encontrada' });
    }
    res.status(200).json(avaliacao);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao obter avaliação', error });
  }
};

const createAvaliacao = async (req, res) => {
  const { de_usuario_id, para_usuario_id, servico_id, nota, comentario } = req.body;
  try {
    const novaAvaliacao = await Avaliacao.create({
      de_usuario_id,
      para_usuario_id,
      servico_id,
      nota,
      comentario
    });
    res.status(201).json(novaAvaliacao);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao criar avaliação', error });
  }
};

module.exports = {
  getAllAvaliacoes,
  getAvaliacaoById,
  createAvaliacao
};
