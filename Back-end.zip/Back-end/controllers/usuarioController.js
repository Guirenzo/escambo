const Usuario = require('../models/usuarioModel'); // importa o model

// Buscar todos os usuários
exports.getAllUsuarios = async (req, res) => {
  try {
    const usuarios = await Usuario.findAll();
    res.json(usuarios); // responde com todos os usuários
  } catch (err) {
    console.error('Erro ao buscar usuários:', err);
    res.status(500).json({ error: 'Erro ao buscar usuários' });
  }
};

// Buscar um usuário por ID
exports.getUsuarioById = async (req, res) => {
  const { id } = req.params;

  try {
    const usuario = await Usuario.findByPk(id); // encontra o usuário pelo ID
    if (usuario) {
      res.json(usuario);
    } else {
      res.status(404).json({ error: 'Usuário não encontrado' });
    }
  } catch (err) {
    console.error('Erro ao buscar usuário:', err);
    res.status(500).json({ error: 'Erro ao buscar usuário' });
  }
};

// Criar um novo usuário
exports.createUsuario = async (req, res) => {
  const { nome, email, senha, tipo } = req.body;

  try {
    const novoUsuario = await Usuario.create({ nome, email, senha, tipo });
    res.status(201).json(novoUsuario); // responde com o novo usuário
  } catch (err) {
    console.error('Erro ao criar usuário:', err);
    res.status(500).json({ error: 'Erro ao criar usuário' });
  }
};

// Atualizar um usuário
exports.updateUsuario = async (req, res) => {
  const { id } = req.params;
  const { nome, email, senha, tipo } = req.body;

  try {
    const usuario = await Usuario.findByPk(id); // encontra o usuário pelo ID
    if (!usuario) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    // Atualiza o usuário
    await usuario.update({ nome, email, senha, tipo });
    res.json(usuario); // responde com o usuário atualizado
  } catch (err) {
    console.error('Erro ao atualizar usuário:', err);
    res.status(500).json({ error: 'Erro ao atualizar usuário' });
  }
};

// Deletar um usuário
exports.deleteUsuario = async (req, res) => {
  const { id } = req.params;

  try {
    const usuario = await Usuario.findByPk(id); // encontra o usuário pelo ID
    if (!usuario) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    // Deleta o usuário
    await usuario.destroy();
    res.status(204).json(); // responde com status 204 (sem conteúdo)
  } catch (err) {
    console.error('Erro ao deletar usuário:', err);
    res.status(500).json({ error: 'Erro ao deletar usuário' });
  }
};

