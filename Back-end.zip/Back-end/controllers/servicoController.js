const Servico = require('../models/servicoModel');

// Buscar todos os serviços
exports.getAllServicos = async (req, res) => {
  try {
    const servicos = await Servico.findAll();
    res.json(servicos);
  } catch (err) {
    console.error('Erro ao buscar serviços:', err);
    res.status(500).json({ error: 'Erro ao buscar serviços' });
  }
};

exports.createServico = async (req, res) => {
    const { titulo, descricao, categoria, preco, freelancer_id, status } = req.body;
  
    try {
      const novoServico = await Servico.create({
        titulo,
        descricao,
        categoria,
        preco,
        freelancer_id,
        status
      });
      res.status(201).json(novoServico);
    } catch (err) {
      console.error('Erro ao criar serviço:', err);  // Aqui será impresso o erro completo no console
      res.status(500).json({ error: 'Erro ao criar serviço', details: err.message });
    }
};



// Buscar um serviço por ID
exports.getServicoById = async (req, res) => {
  const { id } = req.params;

  try {
    const servico = await Servico.findByPk(id);
    if (servico) {
      res.json(servico);
    } else {
      res.status(404).json({ error: 'Serviço não encontrado' });
    }
  } catch (err) {
    console.error('Erro ao buscar serviço:', err);
    res.status(500).json({ error: 'Erro ao buscar serviço' });
  }
};

// Atualizar um serviço
exports.updateServico = async (req, res) => {
  const { id } = req.params;
  const { titulo, descricao, categoria, preco, freelancer_id, status } = req.body;

  try {
    const servico = await Servico.findByPk(id);
    if (!servico) {
      return res.status(404).json({ error: 'Serviço não encontrado' });
    }

    await servico.update({
      titulo,
      descricao,
      categoria,
      preco,
      freelancer_id,
      status
    });
    res.json(servico);
  } catch (err) {
    console.error('Erro ao atualizar serviço:', err);
    res.status(500).json({ error: 'Erro ao atualizar serviço' });
  }
};

// Deletar um serviço
exports.deleteServico = async (req, res) => {
  const { id } = req.params;

  try {
    const servico = await Servico.findByPk(id);
    if (!servico) {
      return res.status(404).json({ error: 'Serviço não encontrado' });
    }

    await servico.destroy();
    res.status(204).json();
  } catch (err) {
    console.error('Erro ao deletar serviço:', err);
    res.status(500).json({ error: 'Erro ao deletar serviço' });
  }
};
