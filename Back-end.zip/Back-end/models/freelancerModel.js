// models/freelancerModel.js
const { DataTypes } = require('sequelize');
const sequelize = require('../utils/database'); // ou ../utils/database, depende de onde você colocou
const Usuario = require('./usuarioModel');

const Freelancer = sequelize.define('Freelancer', {
  usuario_id: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  descricao: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  area_atuacao: {
    type: DataTypes.STRING,
    allowNull: false
  },
  preco: {
    type: DataTypes.FLOAT,
    allowNull: false
  },
  portfolio: {
    type: DataTypes.STRING,
    allowNull: true
  },
  destaque: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  avaliacao_media: {
    type: DataTypes.FLOAT,
    defaultValue: 0
  }
}, {
  tableName: 'freelancers',
  timestamps: false
});


Freelancer.belongsTo(Usuario, { foreignKey: 'usuario_id', as: 'usuario' });
module.exports = Freelancer;
