const { DataTypes } = require('sequelize');
const sequelize = require('../utils/database');

const Usuario = sequelize.define('Usuario', {
  nome: {
    type: DataTypes.STRING(100), // Definido tamanho máximo de 100, como na tabela
    allowNull: true
  },
  email: {
    type: DataTypes.STRING(100), // Definido tamanho máximo de 100, como na tabela
    allowNull: true,
    unique: true
  },
  senha: {
    type: DataTypes.STRING(100), // Definido tamanho máximo de 100, como na tabela
    allowNull: true
  },
  tipo: {
    type: DataTypes.ENUM('cliente', 'freelancer'), // Usando ENUM como no banco
    allowNull: false
  },
  data_criacao: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {
  tableName: 'usuarios',
  timestamps: false // Impede que o Sequelize adicione automaticamente as colunas createdAt e updatedAt
});

module.exports = Usuario;
