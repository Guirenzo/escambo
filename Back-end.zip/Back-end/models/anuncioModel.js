// models/anuncioModel.js
const { DataTypes } = require('sequelize');
const sequelize = require('../utils/database');

const Anuncio = sequelize.define('Anuncio', {
  servico_id: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  tipo: {
    type: DataTypes.ENUM('freelancer', 'empresa'),
    allowNull: true
  },
  titulo: {
    type: DataTypes.STRING(150),
    allowNull: true
  },
  descricao: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  inicio: {
    type: DataTypes.DATEONLY,
    allowNull: true
  },
  fim: {
    type: DataTypes.DATEONLY,
    allowNull: true
  },
  pago: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  valor: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true
  }
}, {
  tableName: 'anuncios',
  timestamps: false
});

module.exports = Anuncio;
