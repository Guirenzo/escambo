// models/avaliacaoModel.js
const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../utils/database'); // Supondo que o arquivo database.js está na pasta utils

const Avaliacao = sequelize.define('avaliacao', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  de_usuario_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'usuarios', // Refere-se à tabela de usuários
      key: 'id'
    }
  },
  para_usuario_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'usuarios', // Refere-se à tabela de usuários
      key: 'id'
    }
  },
  servico_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'servicos', // Refere-se à tabela de serviços
      key: 'id'
    }
  },
  nota: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1,
      max: 5
    }
  },
  comentario: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  data: {
    type: DataTypes.DATE,
    defaultValue: Sequelize.NOW
  }
}, {
  tableName: 'avaliacoes', // Define o nome da tabela no banco de dados
  timestamps: false // Desativa os campos `createdAt` e `updatedAt` se não forem necessários
});

module.exports = Avaliacao;
