const { DataTypes } = require('sequelize');
const sequelize = require('../utils/database');
const Freelancer = require('./freelancerModel');

const Servico = sequelize.define('Servico', {
  titulo: {
    type: DataTypes.STRING(150),
    allowNull: true
  },
  descricao: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  categoria: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  preco: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true
  },
  freelancer_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'freelancers', // A tabela de freelancers
      key: 'id'
    }
  },
  criado_em: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  },
  status: {
    type: DataTypes.ENUM('ativo', 'pausado', 'descontinuado'),
    defaultValue: 'ativo'
  },
  data_criacao: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {
  tableName: 'servicos',
  timestamps: false
});

Servico.belongsTo(Freelancer, { foreignKey: 'freelancer_id', as: 'freelancer' });


module.exports = Servico;
