const { DataTypes } = require('sequelize');
const sequelize = require('../utils/database');

const Pagamento = sequelize.define('Pagamento', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
    allowNull: false
  },
  cliente_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'clientes', // nome da tabela clientes
      key: 'id',
    }
  },
  servico_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'servicos', // nome da tabela servicos
      key: 'id',
    }
  },
  valor_total: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  valor_freelancer: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  valor_comissao: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('pendente', 'pago', 'cancelado'),
    defaultValue: 'pendente',
    allowNull: false
  },
  metodo_pagamento: {
    type: DataTypes.STRING(50),
    allowNull: false
  }
}, {
  tableName: 'pagamentos', // Nome da tabela no banco de dados
});

module.exports = Pagamento;
