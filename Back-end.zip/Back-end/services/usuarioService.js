const usuarioModel = require('../models/usuarioModel');

// Função para criar usuário
exports.criarUsuario = async (usuarioData) => {
  try {
    const novoUsuario = await usuarioModel.create(usuarioData);
    return novoUsuario;
  } catch (error) {
    throw new Error('Erro ao criar usuário');
  }
};

// Função para listar todos os usuários
exports.listarUsuarios = async () => {
  try {
    const usuarios = await usuarioModel.findAll();
    return usuarios;
  } catch (error) {
    throw new Error('Erro ao listar usuários');
  }
};
