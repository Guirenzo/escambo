// routes/anuncioRoutes.js
const express = require('express');
const router = express.Router();
const anuncioController = require('../controllers/anuncioController');

router.get('/', anuncioController.getAllAnuncios);
router.get('/:id', anuncioController.getAnuncioById);
router.post('/', anuncioController.createAnuncio);

module.exports = router;
