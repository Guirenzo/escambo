const express = require('express');
const router = express.Router();
const usuarioController = require('../controllers/usuarioController');

// Definir as rotas para usuários
router.get('/', usuarioController.getAllUsuarios);  // Rota para pegar todos os usuários
router.get('/:id', usuarioController.getUsuarioById);  // Rota para pegar um usuário pelo ID
router.post('/', usuarioController.createUsuario);  // Rota para criar um novo usuário
router.put('/:id', usuarioController.updateUsuario);  // Rota para atualizar um usuário
router.delete('/:id', usuarioController.deleteUsuario);  // Rota para deletar um usuário

// Exportando as rotas
module.exports = router;
