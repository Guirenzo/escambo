const express = require('express');
const router = express.Router();
const pagamentoController = require('../controllers/pagamentoController'); // Certifique-se de que o caminho está correto

// Definindo a rota para obter pagamentos
router.get('/', pagamentoController.getAllPagamentos); // Certifique-se de que a função existe no controller

// Definindo a rota para obter um pagamento específico
router.get('/:id', pagamentoController.getPagamentoById); // Certifique-se de que a função existe no controller

// Definindo a rota para criar um pagamento
router.post('/', pagamentoController.createPagamento); // Certifique-se de que a função existe no controller

module.exports = router;
