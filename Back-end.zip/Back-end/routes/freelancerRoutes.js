const express = require('express');
const router = express.Router();
const freelancerController = require('../controllers/freelancerController');

router.get('/', freelancerController.getAllFreelancers);
router.get('/:id', freelancerController.getFreelancerById);
router.post('/', freelancerController.createFreelancer);



module.exports = router;
