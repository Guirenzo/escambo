const express = require('express');
const router = express.Router();
const servicoController = require('../controllers/servicoController');

// Definir as rotas para serviços
router.get('/', servicoController.getAllServicos);  // Rota para pegar todos os serviços
router.post('/', servicoController.createServico); // Rota para criar um novo serviço
router.get('/:id', servicoController.getServicoById); // Rota para pegar um serviço por ID
router.put('/:id', servicoController.updateServico); // Rota para atualizar um serviço
router.delete('/:id', servicoController.deleteServico); // Rota para deletar um serviço

// Exportar as rotas
module.exports = router;
