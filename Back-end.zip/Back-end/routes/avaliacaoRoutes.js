// routes/avaliacaoRoutes.js
const express = require('express');
const router = express.Router();
const avaliacaoController = require('../controllers/avaliacaoController');

// Rota para pegar todas as avaliações
router.get('/', avaliacaoController.getAllAvaliacoes);

// Rota para pegar uma avaliação específica pelo ID
router.get('/:id', avaliacaoController.getAvaliacaoById);

// Rota para criar uma nova avaliação
router.post('/', avaliacaoController.createAvaliacao);

module.exports = router;
