const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Conexão com o banco de dados
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'servicos_db',
});

connection.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
    return;
  }
  console.log('Conexão com o banco de dados realizada com sucesso!');
});

// Middleware para parsear o corpo das requisições (JSON)
app.use(bodyParser.json());

// Endpoint de teste
app.get('/', (req, res) => {
  res.send('API de Serviços está funcionando!');
});

// CRUD para usuários
app.post('/usuarios', (req, res) => {
  const { nome, email, senha, tipo_usuario } = req.body;

  const query = `INSERT INTO usuarios (nome, email, senha, tipo_usuario) VALUES (?, ?, ?, ?)`;
  connection.query(query, [nome, email, senha, tipo_usuario], (err, result) => {
    if (err) {
      console.error('Erro ao criar usuário:', err);
      res.status(500).send('Erro ao criar usuário');
    } else {
      res.status(201).send('Usuário criado com sucesso');
    }
  });
});

app.get('/usuarios', (req, res) => {
  const query = 'SELECT * FROM usuarios';
  connection.query(query, (err, results) => {
    if (err) {
      console.error('Erro ao listar usuários:', err);
      res.status(500).send('Erro ao listar usuários');
    } else {
      res.json(results);
    }
  });
});

app.put('/usuarios/:id', (req, res) => {
  const { id } = req.params;
  const { nome, email, senha, tipo_usuario } = req.body;

  const query = `UPDATE usuarios SET nome = ?, email = ?, senha = ?, tipo_usuario = ? WHERE id = ?`;
  connection.query(query, [nome, email, senha, tipo_usuario, id], (err, result) => {
    if (err) {
      console.error('Erro ao atualizar usuário:', err);
      res.status(500).send('Erro ao atualizar usuário');
    } else {
      res.send('Usuário atualizado com sucesso');
    }
  });
});

app.delete('/usuarios/:id', (req, res) => {
  const { id } = req.params;

  const query = 'DELETE FROM usuarios WHERE id = ?';
  connection.query(query, [id], (err, result) => {
    if (err) {
      console.error('Erro ao deletar usuário:', err);
      res.status(500).send('Erro ao deletar usuário');
    } else {
      res.send('Usuário deletado com sucesso');
    }
  });
});

// CRUD para clientes
app.post('/clientes', (req, res) => {
  const { nome, email, senha, tipo_usuario } = req.body;

  const query = `INSERT INTO usuarios (nome, email, senha, tipo_usuario) VALUES (?, ?, ?, ?)`;
  connection.query(query, [nome, email, senha, tipo_usuario], (err, result) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao criar cliente' });
    }
    res.status(201).json({ message: 'Cliente criado com sucesso!', userId: result.insertId });
  });
});

app.get('/clientes', (req, res) => {
  const query = 'SELECT * FROM usuarios WHERE tipo_usuario = "cliente"';
  connection.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao obter clientes' });
    }
    res.status(200).json(results);
  });
});

app.put('/clientes/:id', (req, res) => {
  const { id } = req.params;
  const { nome, email, senha } = req.body;

  const query = `UPDATE usuarios SET nome = ?, email = ?, senha = ? WHERE id = ? AND tipo_usuario = "cliente"`;
  connection.query(query, [nome, email, senha, id], (err, result) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao atualizar cliente' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Cliente não encontrado' });
    }
    res.status(200).json({ message: 'Cliente atualizado com sucesso!' });
  });
});

app.delete('/clientes/:id', (req, res) => {
  const { id } = req.params;

  const query = `DELETE FROM usuarios WHERE id = ? AND tipo_usuario = "cliente"`;
  connection.query(query, [id], (err, result) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao deletar cliente' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Cliente não encontrado' });
    }
    res.status(200).json({ message: 'Cliente deletado com sucesso!' });
  });
});

// CRUD para freelancers
app.post('/freelancers', (req, res) => {
  const { usuario_id, descricao_servico, area_atuacao, preco, portifolio } = req.body;

  const query = `INSERT INTO freelancers (usuario_id, descricao_servico, area_atuacao, preco, portifolio) 
                 VALUES (?, ?, ?, ?, ?)`;
  connection.query(query, [usuario_id, descricao_servico, area_atuacao, preco, portifolio], (err, result) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao criar freelancer' });
    }
    res.status(201).json({ message: 'Freelancer criado com sucesso!', freelancerId: result.insertId });
  });
});

app.get('/freelancers', (req, res) => {
  const query = 'SELECT * FROM freelancers';
  connection.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao obter freelancers' });
    }
    res.status(200).json(results);
  });
});

app.put('/freelancers/:id', (req, res) => {
  const { id } = req.params;
  const { descricao_servico, area_atuacao, preco, portifolio } = req.body;

  const query = `UPDATE freelancers SET descricao_servico = ?, area_atuacao = ?, preco = ?, portifolio = ? WHERE id = ?`;
  connection.query(query, [descricao_servico, area_atuacao, preco, portifolio, id], (err, result) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao atualizar freelancer' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Freelancer não encontrado' });
    }
    res.status(200).json({ message: 'Freelancer atualizado com sucesso!' });
  });
});

app.delete('/freelancers/:id', (req, res) => {
  const { id } = req.params;

  const query = `DELETE FROM freelancers WHERE id = ?`;
  connection.query(query, [id], (err, result) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao deletar freelancer' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Freelancer não encontrado' });
    }
    res.status(200).json({ message: 'Freelancer deletado com sucesso!' });
  });
});

// Iniciar o servidor
app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});
