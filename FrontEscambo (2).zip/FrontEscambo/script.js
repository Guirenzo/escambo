document.addEventListener('DOMContentLoaded', () => {
    console.log("Script carregado");

    // === INÍCIO LÓGICA DE ESCOLHA DE PERFIL ===
    const opcoes = document.querySelectorAll('.perfil');
    const telaInicial = document.getElementById('inicio');
    const formCliente = document.getElementById('form-cliente');
    const formFreelancer = document.getElementById('form-freelancer');

    opcoes.forEach(opcao => {
        opcao.addEventListener('click', () => {
            telaInicial.style.display = 'none';

            if (opcao.id === 'escolha-cliente') {
                formCliente.style.display = 'block';
                formFreelancer.style.display = 'none';
            } else if (opcao.id === 'escolha-freelancer') {
                formCliente.style.display = 'none';
                formFreelancer.style.display = 'block';
            }
        });
    });

    const sairCliente = document.getElementById('sair-cliente');
    const sairFreelancer = document.getElementById('sair-freelancer');

    sairCliente.addEventListener('click', () => {
        telaInicial.style.display = 'block';
        formCliente.style.display = 'none';
        formFreelancer.style.display = 'none';
    });

    sairFreelancer.addEventListener('click', () => {
        telaInicial.style.display = 'block';
        formCliente.style.display = 'none';
        formFreelancer.style.display = 'none';
    });

    formCliente.querySelector('button[type="submit"]').addEventListener('click', (e) => {
        e.preventDefault();
        window.location.href = 'cliente-dashboard.html';
    });

    formFreelancer.querySelector('button[type="submit"]').addEventListener('click', (e) => {
        e.preventDefault();
        window.location.href = 'freelancer-dashboard.html';
    });

    const botoesCategoria = document.querySelectorAll('.categorias button');
    botoesCategoria.forEach(botao => {
        botao.addEventListener('click', () => {
            botoesCategoria.forEach(btn => btn.classList.remove('selected'));
            botao.classList.add('selected');
        });
    });
    // === FIM LÓGICA DE ESCOLHA DE PERFIL ===


    // === INÍCIO LÓGICA DE SERVIÇOS DO CLIENTE ===
    const lista = document.getElementById('lista-servicos');
    const categoriaSelect = document.getElementById('categoria');
    const ordenarSelect = document.getElementById('ordenar');

    const servicos = [
        {
            id: 1,
            nome: 'Logo para empresa',
            categoria: 'design',
            preco: 150,
            nota: 4.8,
            destaque: true,
            freelancer: 'João Designer'
        },
        {
            id: 2,
            nome: 'Criação de site institucional',
            categoria: 'dev',
            preco: 500,
            nota: 4.5,
            destaque: false,
            freelancer: 'Maria Dev'
        },
        {
            id: 3,
            nome: 'Campanha no Instagram',
            categoria: 'marketing',
            preco: 300,
            nota: 4.9,
            destaque: true,
            freelancer: 'Ana Social'
        }
    ];

    function renderizarServicos(listaFiltrada) {
        if (!lista) return;

        lista.innerHTML = '';

        listaFiltrada.forEach(servico => {
            const div = document.createElement('div');
            div.className = 'servico-card' + (servico.destaque ? ' destaque' : '');

            div.innerHTML = `
                <h3>${servico.nome}</h3>
                <p><strong>Freelancer:</strong> ${servico.freelancer}</p>
                <p><strong>Categoria:</strong> ${servico.categoria}</p>
                <p><strong>Preço:</strong> R$${servico.preco}</p>
                <p><strong>Avaliação:</strong> ⭐ ${servico.nota}</p>
                <button onclick="contratar(${servico.id})">Contratar</button>
            `;

            lista.appendChild(div);
        });
    }

    function aplicarFiltros() {
        if (!categoriaSelect || !ordenarSelect) return;

        const categoria = categoriaSelect.value;
        const ordenar = ordenarSelect.value;

        let filtrado = [...servicos];

        if (categoria) {
            filtrado = filtrado.filter(s => s.categoria === categoria);
        }

        if (ordenar === 'avaliacao') {
            filtrado.sort((a, b) => b.nota - a.nota);
        } else if (ordenar === 'preco-asc') {
            filtrado.sort((a, b) => a.preco - b.preco);
        } else if (ordenar === 'preco-desc') {
            filtrado.sort((a, b) => b.preco - a.preco);
        }

        renderizarServicos(filtrado);
    }

    if (categoriaSelect && ordenarSelect) {
        categoriaSelect.addEventListener('change', aplicarFiltros);
        ordenarSelect.addEventListener('change', aplicarFiltros);
        aplicarFiltros(); // Render inicial
    }
    // === FIM LÓGICA DE SERVIÇOS ===

    
});

function contratar(id) {
    alert(`Serviço ${id} contratado! (integração com InfinitPay aqui)`);
}
