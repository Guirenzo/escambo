document.addEventListener('DOMContentLoaded', () => {
  const servicoTitulo = localStorage.getItem('servicoTitulo');
  const servicoCategoria = localStorage.getItem('servicoCategoria');
  const valorServico = localStorage.getItem('valorServico');
  const clienteNome = localStorage.getItem('clienteNome');
  const clienteEmail = localStorage.getItem('clienteEmail');

  // Mostrar título e categoria no resumo do serviço:
  document.getElementById('resumo-titulo').textContent = servicoCategoria
    ? `${servicoTitulo} (${servicoCategoria})`
    : servicoTitulo || 'Serviço não disponível';

  document.getElementById('resumo-preco').textContent = valorServico
    ? parseFloat(valorServico).toFixed(2)
    : '0.00';

  // Informações do cliente
  let resumoCliente = document.getElementById('resumo-cliente');
  if (!resumoCliente) {
    resumoCliente = document.createElement('div');
    resumoCliente.id = 'resumo-cliente';
    resumoCliente.style.marginTop = '20px';
    resumoCliente.innerHTML = `
      <h3>Informações do Cliente</h3>
      <p><strong>Nome:</strong> <span id="cliente-nome"></span></p>
      <p><strong>Email:</strong> <span id="cliente-email"></span></p>
    `;
    document.querySelector('.resumo-servico').appendChild(resumoCliente);
  }

  document.getElementById('cliente-nome').textContent = clienteNome || 'Não disponível';
  document.getElementById('cliente-email').textContent = clienteEmail || 'Não disponível';
  // Formulário de pagamento
  const formPagamento = document.getElementById('pagamento-form');
  formPagamento.addEventListener('submit', (e) => {
    e.preventDefault();

    // Aqui você faria a validação dos dados e integraria com API de pagamento

    alert('Pagamento realizado com sucesso! (simulado)');

    // Opcional: limpar localStorage, redirecionar etc.
    localStorage.removeItem('servicoId');
    localStorage.removeItem('servicoTitulo');
    localStorage.removeItem('servicoCategoria');
    localStorage.removeItem('valorServico');
    localStorage.removeItem('clienteNome');
    localStorage.removeItem('clienteEmail');

    // Redirecionar para página de sucesso ou dashboard
    window.location.href = 'index.html';
  });
});
