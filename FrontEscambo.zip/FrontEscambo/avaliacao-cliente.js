document.addEventListener('DOMContentLoaded', () => {
  const abrirBtn = document.getElementById('abrir-avaliacao');
  const boxAvaliacao = document.getElementById('box-avaliacao');
  const fecharBtn = document.getElementById('fechar-avaliacao');
  const enviarBtn = document.getElementById('enviar-avaliacao');
  const selectUsuario = document.getElementById('usuario-para-avaliar');
  const inputNota = document.getElementById('nota');
  const textareaComentario = document.getElementById('comentario');

  // Função para abrir o modal
  abrirBtn.addEventListener('click', () => {
    boxAvaliacao.style.display = 'block';
    carregarUsuariosParaAvaliar();
  });

  // Fechar modal
  fecharBtn.addEventListener('click', () => {
    boxAvaliacao.style.display = 'none';
    limparFormulario();
  });

  // Enviar avaliação
  enviarBtn.addEventListener('click', async () => {
    const paraUsuarioId = selectUsuario.value;
    const nota = parseInt(inputNota.value);
    const comentario = textareaComentario.value.trim();
    const deUsuarioId = localStorage.getItem('usuarioId'); // ID do usuário que está avaliando
    const servicoId = null; // Se quiser, pode adaptar para enviar o id do serviço

    if (!paraUsuarioId) {
      alert('Selecione um usuário para avaliar.');
      return;
    }

    if (!nota || nota < 1 || nota > 5) {
      alert('Digite uma nota válida entre 1 e 5.');
      return;
    }

    try {
      const res = await fetch('http://localhost:3000/avaliacoes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          de_usuario_id: deUsuarioId,
          para_usuario_id: paraUsuarioId,
          servico_id: servicoId,
          nota,
          comentario,
        }),
      });

      if (!res.ok) throw new Error('Erro ao enviar avaliação');

      alert('Avaliação enviada com sucesso!');
      boxAvaliacao.style.display = 'none';
      limparFormulario();

    } catch (err) {
      alert('Erro ao enviar avaliação: ' + err.message);
    }
  });

  // Função para limpar formulário
  function limparFormulario() {
    selectUsuario.value = '';
    inputNota.value = '';
    textareaComentario.value = '';
  }

  // Função para carregar usuários que podem ser avaliados
  async function carregarUsuariosParaAvaliar() {
    selectUsuario.innerHTML = '<option value="">Selecione um usuário</option>';
    try {
      // Exemplo: buscar freelancers, mas pode adaptar para clientes se quiser
      const res = await fetch('http://localhost:3000/freelancers');
      const freelancers = await res.json();

      freelancers.forEach(f => {
        const option = document.createElement('option');
        option.value = f.usuario_id;
        option.textContent = f.usuario?.nome || `Freelancer #${f.usuario_id}`;
        selectUsuario.appendChild(option);
      });
    } catch (err) {
      console.error('Erro ao carregar usuários para avaliação:', err);
      alert('Erro ao carregar lista de usuários para avaliação.');
    }
  }
});
