const BASE_URL = 'http://localhost:3000';

document.addEventListener('DOMContentLoaded', () => {
  const clienteNome = localStorage.getItem('clienteNome') || 'Cliente';
  const titulo = document.querySelector('.cliente-area h1');
  if (titulo) {
    titulo.textContent = `Bem-vindo, ${clienteNome}!`;
  }

  const lista = document.getElementById('lista-servicos');
  const categoriaSelect = document.getElementById('categoria');
  const ordenarSelect = document.getElementById('ordenar');
  let servicos = [];

  async function buscarServicos() {
    try {
      const resposta = await fetch(`${BASE_URL}/servicos`);
      if (!resposta.ok) throw new Error(`Erro HTTP: ${resposta.status}`);

      const dados = await resposta.json();
      servicos = dados;

      popularCategorias(servicos);
      aplicarFiltros();
    } catch (erro) {
      console.error('Erro ao carregar serviços:', erro);
      lista.innerHTML = '<p>Erro ao carregar serviços. Tente novamente mais tarde.</p>';
    }
  }

  function popularCategorias(servicos) {
    const categoriasUnicas = [...new Set(servicos.map(s => s.categoria))].sort();
    categoriaSelect.innerHTML = '<option value="">Todas</option>';

    categoriasUnicas.forEach(cat => {
      const option = document.createElement('option');
      option.value = cat;
      option.textContent = cat;
      categoriaSelect.appendChild(option);
    });
  }

  function renderizarServicos(listaFiltrada) {
    lista.innerHTML = '';

    if (listaFiltrada.length === 0) {
      lista.innerHTML = '<p>Nenhum serviço encontrado.</p>';
      return;
    }

    listaFiltrada.forEach(servico => {
      const freelancerNome = servico.freelancer && servico.freelancer.usuario ? servico.freelancer.usuario.nome : 'Freelancer desconhecido';

      const div = document.createElement('div');
      div.className = 'servico-card' + (servico.destaque ? ' destaque' : '');
      div.innerHTML = `
        <h3>${servico.titulo}</h3>
        <p><strong>Categoria:</strong> ${servico.categoria}</p>
        <p><strong>Preço:</strong> R$${parseFloat(servico.preco).toFixed(2)}</p>
        <p><strong>Freelancer:</strong> ${freelancerNome}</p>
        <button class="btn-contratar"
          data-id="${servico.id}"
          data-freelancer="${servico.freelancer_id}"
          data-preco="${servico.preco}"
          data-titulo="${servico.titulo}"
          data-categoria="${servico.categoria}">
          Contratar
        </button>
      `;

      lista.appendChild(div);
    });

    document.querySelectorAll('.btn-contratar').forEach(botao => {
      botao.addEventListener('click', () => {
        const servicoId = botao.getAttribute('data-id');
        const freelancerId = botao.getAttribute('data-freelancer');
        const preco = botao.getAttribute('data-preco');
        const titulo = botao.getAttribute('data-titulo');
        const categoria = botao.getAttribute('data-categoria');

        localStorage.setItem('servicoId', servicoId);
        localStorage.setItem('freelancerId', freelancerId);
        localStorage.setItem('valorServico', preco);
        localStorage.setItem('servicoTitulo', titulo);
        localStorage.setItem('servicoCategoria', categoria);

        const clienteNome = localStorage.getItem('clienteNome') || 'Não disponível';
        const clienteEmail = localStorage.getItem('clienteEmail') || 'Não disponível';
        localStorage.setItem('clienteNome', clienteNome);
        localStorage.setItem('clienteEmail', clienteEmail);

        window.location.href = 'pagamento.html';
      });
    });
  }

  function aplicarFiltros() {
    const categoria = categoriaSelect.value;
    const ordenar = ordenarSelect.value;

    let filtrado = [...servicos];

    if (categoria) {
      filtrado = filtrado.filter(s => s.categoria === categoria);
    }

    if (ordenar === 'preco-asc') {
      filtrado.sort((a, b) => parseFloat(a.preco) - parseFloat(b.preco));
    } else if (ordenar === 'preco-desc') {
      filtrado.sort((a, b) => parseFloat(b.preco) - parseFloat(a.preco));
    }

    renderizarServicos(filtrado);
  }

  categoriaSelect.addEventListener('change', aplicarFiltros);
  ordenarSelect.addEventListener('change', aplicarFiltros);

  buscarServicos();
});
