const BASE_URL = 'http://localhost:3000'; 

document.addEventListener("DOMContentLoaded", () => {
  const listaServicos = document.getElementById("lista-servicos");
  const modal = document.getElementById("modal-servico");
  const fecharModal = document.getElementById("fechar-modal");
  const btnAdicionar = document.getElementById("adicionar-servico");
  const form = document.getElementById("form-servico");

  let editandoId = null;

  // 👉 Abrir modal
  btnAdicionar.addEventListener("click", () => {
    modal.classList.remove("hidden");
    form.reset();
    editandoId = null;
    document.getElementById("titulo-modal").textContent = "Novo Serviço";
  });

  // 👉 Fechar modal
  fecharModal.addEventListener("click", () => {
    modal.classList.add("hidden");
  });

  // 👉 Submeter formulário
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const servico = {
      titulo: document.getElementById("titulo").value,
      descricao: document.getElementById("descricao").value,
      categoria: document.getElementById("categoria").value,
      preco: parseFloat(document.getElementById("preco").value),
      destaque: document.getElementById("destaque").checked,
    };


    try {
      if (editandoId) {
        await fetch(`${BASE_URL}/servicos/${editandoId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(servico),
        });
      } else {
        await fetch(`${BASE_URL}/servicos`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(servico),
        });
      }

      await carregarServicos();
      modal.classList.add("hidden");
    } catch (err) {
      alert("Erro ao salvar serviço");
      console.error(err);
    }
  });

  // 👉 Listar serviços
  async function carregarServicos() {
    listaServicos.innerHTML = "<p>Carregando...</p>";

    try {
      const res = await fetch(`${BASE_URL}/servicos`);
      const servicos = await res.json();

      listaServicos.innerHTML = "";

      servicos.forEach((servico) => {
        const div = document.createElement("div");
        div.className = "servico-card"; // sem destaque, pois não tem campo

        div.innerHTML = `
          <h3>${servico.titulo || "Título não informado"}</h3>
          <p><strong>Descrição:</strong> ${servico.descricao || "Descrição não informada"}</p>
          <p><strong>Categoria:</strong> ${servico.categoria || "Categoria não informada"}</p>
          <p><strong>Preço:</strong> R$ ${servico.preco ? parseFloat(servico.preco).toFixed(2) : "0.00"}</p>
          <button class="editar-btn" data-id="${servico.id}">Editar</button>
          <button class="excluir-btn" data-id="${servico.id}">Excluir</button>
        `;


        listaServicos.appendChild(div);
      });


      // Botões editar
      document.querySelectorAll(".editar-btn").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const id = btn.dataset.id;

          try {
            const res = await fetch(`${BASE_URL}/servicos/${id}`);
            const servico = await res.json();

            document.getElementById("titulo").value = servico.titulo || "";
            document.getElementById("descricao").value = servico.descricao || "";
            document.getElementById("categoria").value = servico.categoria || "";
            document.getElementById("preco").value = servico.preco || "";
            document.getElementById("destaque").checked = servico.destaque || false;


            editandoId = servico.id;
            document.getElementById("titulo-modal").textContent = "Editar Serviço";
            modal.classList.remove("hidden");
          } catch (err) {
            alert("Erro ao buscar serviço");
          }
        });
      });

      // Botões excluir
      document.querySelectorAll(".excluir-btn").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const id = btn.dataset.id;
          if (confirm("Deseja realmente excluir este serviço?")) {
            try {
              await fetch(`${BASE_URL}/servicos/${id}`, {
                method: "DELETE",
              });
              await carregarServicos();
            } catch (err) {
              alert("Erro ao excluir");
            }
          }
        });
      });
    } catch (error) {
      listaServicos.innerHTML = "<p>Erro ao carregar serviços.</p>";
    }
  }

  // 👉 Inicial
  carregarServicos();
});
