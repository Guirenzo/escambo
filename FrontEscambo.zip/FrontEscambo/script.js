document.addEventListener('DOMContentLoaded', () => {
  const escolhaCliente = document.getElementById('escolha-cliente');
  const escolhaFreelancer = document.getElementById('escolha-freelancer');

  const formContainer = document.getElementById('form-container');
  const formCliente = document.getElementById('form-cliente');
  const formFreelancer = document.getElementById('form-freelancer');

  const sairCliente = document.getElementById('sair-cliente');
  const sairFreelancer = document.getElementById('sair-freelancer');

  const inicioSection = document.getElementById('inicio');

  // Mostrar formulário do cliente
  escolhaCliente.addEventListener('click', () => {
    inicioSection.style.display = 'none';
    formContainer.style.display = 'flex';
    formCliente.style.display = 'block';
    formFreelancer.style.display = 'none';
  });

  // Mostrar formulário do freelancer
  escolhaFreelancer.addEventListener('click', () => {
    inicioSection.style.display = 'none';
    formContainer.style.display = 'flex';
    formFreelancer.style.display = 'block';
    formCliente.style.display = 'none';
  });

  // Botão sair cliente volta à tela inicial
  sairCliente.addEventListener('click', () => {
    formContainer.style.display = 'none';
    formCliente.style.display = 'none';
    inicioSection.style.display = 'block';
  });

  // Botão sair freelancer volta à tela inicial
  sairFreelancer.addEventListener('click', () => {
    formContainer.style.display = 'none';
    formFreelancer.style.display = 'none';
    inicioSection.style.display = 'block';
  });

  // Submit Cliente
  formCliente.addEventListener('submit', async (e) => {
    e.preventDefault();

    const nome = document.getElementById('nomeCliente').value.trim();
    const email = document.getElementById('emailCliente').value.trim();
    const senha = document.getElementById('senhaCliente').value.trim();
    const servico = document.getElementById('servicoCliente').value.trim();

    if (!nome || !email || !senha || !servico) {
      alert('Por favor, preencha todos os campos do Cliente.');
      return;
    }

    try {
      const resUsuario = await fetch('http://localhost:3000/usuarios', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome, email, senha, tipo: 'cliente' }),
      });

      if (!resUsuario.ok) throw new Error('Erro ao criar usuário cliente');

      // 👉 Salvar o nome no localStorage
      localStorage.setItem('clienteNome', nome);
      localStorage.setItem('clienteEmail', email);


      alert('Cadastro do Cliente realizado com sucesso!');
      window.location.href = 'cliente-dashboard.html';

      formCliente.reset();
      formContainer.style.display = 'none';
      inicioSection.style.display = 'block';

    } catch (err) {
      alert(err.message);
      console.error(err);
    }
  });


  formFreelancer.addEventListener('submit', async (e) => {
    e.preventDefault();

    const nome = document.getElementById('nomeFreelancer').value.trim();
    const email = document.getElementById('emailFreelancer').value.trim();
    const senha = document.getElementById('senhaFreelancer').value.trim();
    const descricao = document.getElementById('descricao').value.trim();
    const area_atuacao = document.getElementById('area').value.trim();
    const preco = document.getElementById('preco').value.trim();

    if (!nome || !email || !senha || !descricao || !area_atuacao || !preco) {
      alert('Por favor, preencha todos os campos do Freelancer.');
      return;
    }

    try {
      // Primeiro: Criar o usuário
      const resUsuario = await fetch('http://localhost:3000/usuarios', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nome,
          email,
          senha,
          tipo: 'freelancer'
        }),
      });

      if (!resUsuario.ok) {
        const erro = await resUsuario.text();
        throw new Error(`Erro ao criar usuário: ${erro}`);
      }

      const usuarioData = await resUsuario.json();
      const usuarioId = usuarioData.id;  // Pegando o ID do usuário criado

      // Agora: Criar o Freelancer
      const resFreelancer = await fetch('http://localhost:3000/freelancers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          usuario_id: usuarioId,
          descricao,
          area_atuacao,
          preco,
          portfolio: '',
          destaque: false,
          avaliacao_media: '0.0'
        }),
      });

      if (!resFreelancer.ok) {
        const erro = await resFreelancer.text();
        throw new Error(`Erro ao cadastrar freelancer: ${erro}`);
      }

      alert('Cadastro do Freelancer realizado com sucesso!');
      window.location.href = 'freelancer-dashboard.html';

      formFreelancer.reset();
      formContainer.style.display = 'none';
      inicioSection.style.display = 'block';

    } catch (err) {
      alert(err.message);
      console.error(err);
    }
  });



});
