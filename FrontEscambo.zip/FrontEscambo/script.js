document.addEventListener('DOMContentLoaded', () => {
    // Seletores principais
    const opcoes = document.querySelectorAll('.perfil');
    const telaInicial = document.getElementById('inicio');
    const formCliente = document.getElementById('form-cliente');
    const formFreelancer = document.getElementById('form-freelancer');

    // Alterna entre os formulários
    opcoes.forEach(opcao => {
        opcao.addEventListener('click', () => {
            telaInicial.style.display = 'none';

            if (opcao.id === 'escolha-cliente') {
                formCliente.style.display = 'block';
                formFreelancer.style.display = 'none';
            } else if (opcao.id === 'escolha-freelancer') {
                formCliente.style.display = 'none';
                formFreelancer.style.display = 'block';
            }
        });
    });

    // Botões de "Sair"
    const sairCliente = document.getElementById('sair-cliente');
    const sairFreelancer = document.getElementById('sair-freelancer');

    sairCliente.addEventListener('click', () => {
        telaInicial.style.display = 'block';
        formCliente.style.display = 'none';
        formFreelancer.style.display = 'none';
    });

    sairFreelancer.addEventListener('click', () => {
        telaInicial.style.display = 'block';
        formCliente.style.display = 'none';
        formFreelancer.style.display = 'none';
    });

    // Redirecionamento ao clicar no botão "Continuar"
    formCliente.querySelector('button[type="submit"]').addEventListener('click', (e) => {
        e.preventDefault();
        window.location.href = 'cliente-dashboard.html';
    });

    formFreelancer.querySelector('button[type="submit"]').addEventListener('click', (e) => {
        e.preventDefault();
        window.location.href = 'freelancer-dashboard.html';
    });
});
